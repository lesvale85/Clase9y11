package com.cuscatlan.myfirstbankingapp.presentation.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil3.compose.AsyncImage
import com.cuscatlan.myfirstbankingapp.domain.model.Pokemon
import org.koin.androidx.compose.koinViewModel
import java.util.Locale

private val Ink = Color(0xFF17232C)
private val Coral = Color(0xFFFF6B5E)
private val Cream = Color(0xFFFFF9F1)
private val Muted = Color(0xFF74818A)

@Composable
fun HomeScreen(
    viewModel: PokemonListViewModel = koinViewModel(),
    onPokemonClick: (Pokemon) -> Unit,
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize().background(Cream).statusBarsPadding().padding(horizontal = 20.dp)) {
        Spacer(Modifier.height(16.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("POKÉDEX", fontSize = 12.sp, letterSpacing = 3.sp, color = Coral, fontWeight = FontWeight.ExtraBold)
                Text("Explora el mundo\nPokémon", fontSize = 30.sp, lineHeight = 34.sp, color = Ink, fontWeight = FontWeight.Black)
            }
            Box(Modifier.size(52.dp).clip(CircleShape).background(Coral), Alignment.Center) {
                Text("P", fontSize = 30.sp, color = Color.White, fontWeight = FontWeight.Black)
            }
        }
        Spacer(Modifier.height(18.dp))
        OutlinedTextField(
            value = state.query,
            onValueChange = viewModel::search,
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Buscar Pokémon…") },
            leadingIcon = { Text("⌕", fontSize = 26.sp, color = Muted) },
            singleLine = true,
            shape = RoundedCornerShape(18.dp),
            colors = OutlinedTextFieldDefaults.colors(
                unfocusedContainerColor = Color.White,
                focusedContainerColor = Color.White,
                unfocusedBorderColor = Color(0xFFECE4DB),
                focusedBorderColor = Coral,
            ),
        )
        // Favorito y Refresco
        Spacer(Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            FilterChip(
                selected = state.showOnlyFavorites,
                onClick = viewModel::toggleFavoritesFilter,
                label = {
                    Text(if (state.showOnlyFavorites) "♥ Ver Todos" else "♡ Solo Favoritos")
                },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = Coral.copy(alpha = 0.2f),
                    selectedLabelColor = Coral,
                ),
            )
            IconButton(onClick = { viewModel.setCompact(!state.isCompact) }) {
                Text(if (state.isCompact) "⊞" else "⊟", fontSize = 22.sp, color = Coral)
            }
            IconButton(onClick = viewModel::forceRefresh) {
                Text("↻", fontSize = 22.sp, color = Coral, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(Modifier.height(16.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Pokémon", Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Ink)
            Text("${state.filteredPokemon.size} mostrados", color = Muted, fontSize = 12.sp)
        }
        Spacer(Modifier.height(10.dp))
        when {
            state.isLoading && state.pokemon.isEmpty() -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator(color = Coral) }
            state.error != null && state.pokemon.isEmpty() -> Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text(state.error.orEmpty(), color = Ink, textAlign = TextAlign.Center)
                TextButton(onClick = viewModel::forceRefresh) { Text("Reintentar", color = Coral) }
            }
            state.filteredPokemon.isEmpty() -> Box(Modifier.fillMaxSize(), Alignment.Center) { Text("No encontramos ningún Pokémon", color = Muted) }
            else -> LazyVerticalGrid(
                columns = GridCells.Fixed(if (state.isCompact) 3 else 2),
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 24.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                items(state.filteredPokemon, key = { it.id }) { pokemon ->
                    PokemonCard(pokemon = pokemon, isCompact = state.isCompact, onClick = { onPokemonClick(pokemon) })
                }
            }
        }
    }
}

@Composable
private fun PokemonCard(pokemon: Pokemon, isCompact: Boolean, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(if (isCompact) 16.dp else 22.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    ) {
        Column(Modifier.fillMaxWidth().padding(if (isCompact) 8.dp else 12.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("#${pokemon.id.toString().padStart(3, '0')}", Modifier.weight(1f), color = Muted, fontSize = if (isCompact) 10.sp else 11.sp, fontWeight = FontWeight.Bold)
                Text("↗", color = Coral, fontSize = if (isCompact) 14.sp else 16.sp)
            }
            Box(Modifier.fillMaxWidth().height(if (isCompact) 84.dp else 118.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFFFFF0E9)), Alignment.Center) {
                AsyncImage(model = pokemon.imageUrl, contentDescription = pokemon.name, modifier = Modifier.size(if (isCompact) 78.dp else 112.dp))
            }
            Spacer(Modifier.height(if (isCompact) 6.dp else 10.dp))
            Text(pokemon.name.replaceFirstChar { it.titlecase(Locale.ROOT) }, fontSize = if (isCompact) 13.sp else 16.sp, fontWeight = FontWeight.Bold, color = Ink, maxLines = 1)
            if (!isCompact) {
                Text("Ver detalles", fontSize = 11.sp, color = Muted)
            }
        }
    }
}

package com.cuscatlan.myfirstbankingapp.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
interface PokemonDetailDao {
    @Transaction
    @Query("""
        SELECT * FROM pokemon_details WHERE pokemonId =
        (SELECT id FROM pokemon WHERE name = :name)
    """)
    fun observe(name: String): Flow<CachedPokemonDetail?>

    @Upsert
    suspend fun upsert(row: PokemonDetailEntity)

    @Query("DELETE FROM pokemon_stats WHERE pokemonId = :id")
    suspend fun deleteStats(id: Int)

    @Insert
    suspend fun insertStats(rows: List<PokemonStatEntity>)
}

package com.cuscatlan.myfirstbankingapp.data.mapper

import com.cuscatlan.myfirstbankingapp.data.local.CachedPokemonDetail
import com.cuscatlan.myfirstbankingapp.data.local.PokemonDetailEntity
import com.cuscatlan.myfirstbankingapp.data.local.PokemonEntity
import com.cuscatlan.myfirstbankingapp.data.remote.PokemonDto
import com.cuscatlan.myfirstbankingapp.data.remote.PokemonSummaryDto
import com.cuscatlan.myfirstbankingapp.domain.model.Pokemon
import com.cuscatlan.myfirstbankingapp.domain.model.PokemonDetail
import com.cuscatlan.myfirstbankingapp.domain.model.PokemonStat
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

private const val OFFICIAL_ARTWORK_BASE_URL =
    "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork"

private val gson = Gson()

fun PokemonSummaryDto.toDomain(): Pokemon {
    val id = url.trimEnd('/').substringAfterLast('/').toInt()
    return Pokemon(
        id = id,
        name = name,
        imageUrl = "$OFFICIAL_ARTWORK_BASE_URL/$id.png",
    )
}

fun PokemonSummaryDto.toEntity(): PokemonEntity {
    val id = url.trimEnd('/').substringAfterLast('/').toInt()
    return PokemonEntity(
        id = id,
        name = name,
        imageUrl = "$OFFICIAL_ARTWORK_BASE_URL/$id.png",
    )
}

fun PokemonDto.toSummaryEntity(): PokemonEntity = PokemonEntity(
    id = id,
    name = name,
    imageUrl = sprites.other?.officialArtwork?.frontDefault ?: "$OFFICIAL_ARTWORK_BASE_URL/$id.png",
)

fun PokemonDto.toDetailEntity(): PokemonDetailEntity = PokemonDetailEntity(
    pokemonId = id,
    heightDm = height,
    weightHg = weight,
    imageUrl = sprites.other?.officialArtwork?.frontDefault ?: "$OFFICIAL_ARTWORK_BASE_URL/$id.png",
    typeJson = gson.toJson(types.map { it.type.name }),
    lastUpdate = System.currentTimeMillis(),
)

fun PokemonDto.toDomain(): PokemonDetail = PokemonDetail(
    id = id,
    name = name,
    heightMeters = height / 10f,
    weightKilograms = weight / 10f,
    imageUrl = sprites.other?.officialArtwork?.frontDefault,
    types = types.map { it.type.name },
    stats = stats.map { PokemonStat(name = it.stat.name, baseValue = it.baseStat) },
)

fun PokemonEntity.toDomain(): Pokemon = Pokemon(
    id = id,
    name = name,
    imageUrl = imageUrl,
)

fun CachedPokemonDetail.toDomain(): PokemonDetail {
    val typeListType = object : TypeToken<List<String>>() {}.type
    val typesList: List<String> = try {
        gson.fromJson(detail.typeJson, typeListType) ?: emptyList()
    } catch (_: Exception) {
        emptyList()
    }

    return PokemonDetail(
        id = pokemon.id,
        name = pokemon.name,
        heightMeters = detail.heightDm / 10f,
        weightKilograms = detail.weightHg / 10f,
        imageUrl = detail.imageUrl,
        types = typesList,
        stats = stats.sortedBy { it.position }.map {
            PokemonStat(name = it.name, baseValue = it.baseValue)
        },
    )
}

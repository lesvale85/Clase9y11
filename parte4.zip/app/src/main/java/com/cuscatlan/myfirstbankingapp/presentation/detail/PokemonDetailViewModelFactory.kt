package com.cuscatlan.myfirstbankingapp.presentation.detail

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.cuscatlan.myfirstbankingapp.domain.usecase.GetPokemonDetailUseCase
import com.cuscatlan.myfirstbankingapp.domain.usecase.ToggleFavoriteUseCase

class PokemonDetailViewModelFactory(
    private val name: String,
    private val getPokemonDetail: GetPokemonDetailUseCase,
    private val toggleFavoriteUseCase: ToggleFavoriteUseCase,
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(PokemonDetailViewModel::class.java)) {
            return PokemonDetailViewModel(name, getPokemonDetail, toggleFavoriteUseCase) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

package com.cuscatlan.myfirstbankingapp.presentation.detail

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil3.compose.AsyncImage
import java.util.Locale

private val Ink = Color(0xFF17232C)
private val Coral = Color(0xFFFF6B5E)
private val Cream = Color(0xFFFFF9F1)

@Composable
fun PokemonDetailScreen(viewModel: PokemonDetailViewModel, onBack: () -> Unit) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val item = state.pokemon
    Column(Modifier.fillMaxSize().background(Cream).statusBarsPadding().padding(20.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            TextButton(onClick = onBack, contentPadding = PaddingValues(0.dp)) {
                Text("←  Pokédex", color = Ink, fontWeight = FontWeight.Bold)
            }
            IconButton(
                onClick = viewModel::toggleFavorite,
                modifier = Modifier.size(48.dp)
            ) {
                Text(
                    text = if (state.isFavorite) "♥" else "♡",
                    fontSize = 28.sp,
                    color = if (state.isFavorite) Coral else Ink,
                )
            }
        }
        when {
            state.isLoading -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                CircularProgressIndicator(color = Coral)
            }
            state.error != null -> Column(
                Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Text(state.error.orEmpty(), color = Ink)
                TextButton(onClick = viewModel::loadPokemon) { Text("Reintentar", color = Coral) }
            }
            item != null -> {
                Spacer(Modifier.height(12.dp))
                Text("#${item.id.toString().padStart(3, '0')}", color = Coral, fontWeight = FontWeight.Bold)
                Text(item.name.replaceFirstChar { it.titlecase(Locale.ROOT) }, fontSize = 38.sp, fontWeight = FontWeight.Black, color = Ink)
                Box(Modifier.fillMaxWidth().height(260.dp).clip(RoundedCornerShape(32.dp)).background(Color(0xFFFFE6D9)), Alignment.Center) {
                    AsyncImage(model = item.imageUrl, contentDescription = item.name, modifier = Modifier.size(240.dp))
                }
                Spacer(Modifier.height(20.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    item.types.forEach { type ->
                        Surface(shape = RoundedCornerShape(50), color = Coral.copy(alpha = .14f)) {
                            Text(type.uppercase(), Modifier.padding(horizontal = 16.dp, vertical = 8.dp), color = Coral, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Spacer(Modifier.height(24.dp))
                Text("Datos básicos", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Ink)
                Text("Altura  ${item.heightMeters} m     Peso  ${item.weightKilograms} kg", Modifier.padding(top = 8.dp), color = Ink)
                Spacer(Modifier.height(20.dp))
                Text("Estadísticas", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Ink)
                Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState())) {
                    item.stats.forEach { stat ->
                        Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(stat.name.replace('-', ' ').uppercase(), Modifier.width(118.dp), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Ink)
                            LinearProgressIndicator(progress = { stat.baseValue.coerceAtMost(150) / 150f }, modifier = Modifier.weight(1f).height(8.dp).clip(RoundedCornerShape(10.dp)), color = Coral, trackColor = Color(0xFFE8DED5))
                            Text("  ${stat.baseValue}", color = Ink, fontWeight = FontWeight.Bold, textAlign = TextAlign.End)
                        }
                    }
                }
            }
        }
    }
}

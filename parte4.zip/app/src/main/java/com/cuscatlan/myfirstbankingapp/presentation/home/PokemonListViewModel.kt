package com.cuscatlan.myfirstbankingapp.presentation.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.cuscatlan.myfirstbankingapp.domain.repository.FavoriteRepository
import com.cuscatlan.myfirstbankingapp.domain.repository.SettingRepository
import com.cuscatlan.myfirstbankingapp.domain.usecase.GetPokemonListUseCase
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class PokemonListViewModel(
    private val getPokemonList: GetPokemonListUseCase,
    private val favoriteRepository: FavoriteRepository,
    private val settingRepository: SettingRepository //Repositorio compacto
) : ViewModel() {
    private val _state = MutableStateFlow(PokemonListUiState())
    val state = _state.asStateFlow()

    init {
        observePokemon()
        observeFavorites()
        observeSettings() //Compacto
        loadPokemon()
    }

    private fun observePokemon() {
        viewModelScope.launch {
            getPokemonList.observePokemonList().collect { pokemonList ->
                _state.update { 
                    it.copy(
                        isLoading = false, 
                        pokemon = pokemonList,
                        error = if (pokemonList.isEmpty()) it.error else null
                    ) 
                }
            }
        }
    }

    private fun observeFavorites() {
        viewModelScope.launch {
            favoriteRepository.getFavorites().collect { favoritesList ->
                _state.update { it.copy(favoriteNames = favoritesList.map { name -> name.lowercase() }.toSet()) }
            }
        }
    }

    private fun observeSettings() {
        viewModelScope.launch {
            settingRepository.compact.collect { isCompact ->
                _state.update { it.copy(isCompact = isCompact) }
            }
        }
    }

    fun search(query: String) = _state.update { it.copy(query = query) }

    fun setCompact(value: Boolean){
        if (state.value.isSavingCompact) return
        _state.update { it.copy(isSavingCompact = true, settingsError = null) }
        viewModelScope.launch{
            try{
                settingRepository.SetCompact(value)
            } catch (cancelled: CancellationException){
                throw cancelled
            } catch (_: Exception){
                _state.update { it.copy(settingsError= "No se pudo guardar la vista") }
            } finally {
                _state.update { it.copy(isSavingCompact = false) }
            }
        }
    }

    fun toggleFavoritesFilter() {
        _state.update { it.copy(showOnlyFavorites = !it.showOnlyFavorites) }
    }

    fun forceRefresh() {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true, error = null) }
            try {
                getPokemonList.forceRefresh()
                _state.update { it.copy(isLoading = false, error = null) }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Exception) {
                _state.update {
                    it.copy(
                        isLoading = false,
                        error = if (state.value.pokemon.isEmpty()) "No pudimos refrescar los datos de PokeAPI. Revisa tu conexión." else null,
                    )
                }
            }
        }
    }

    fun loadPokemon() {
        viewModelScope.launch {
            if (state.value.pokemon.isEmpty()) {
                _state.update { it.copy(isLoading = true, error = null) }
            }
            try {
                getPokemonList.refresh()
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Exception) {
                // Background refresh failed, cached list in Room remains displayed
            }
        }
    }
}

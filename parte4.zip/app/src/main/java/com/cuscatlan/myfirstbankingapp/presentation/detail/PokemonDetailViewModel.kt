package com.cuscatlan.myfirstbankingapp.presentation.detail

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.cuscatlan.myfirstbankingapp.domain.usecase.GetPokemonDetailUseCase
import com.cuscatlan.myfirstbankingapp.domain.usecase.ToggleFavoriteUseCase
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class PokemonDetailViewModel(
    private val name: String,
    private val getPokemonDetail: GetPokemonDetailUseCase,
    private val toggleFavoriteUseCase: ToggleFavoriteUseCase,
) : ViewModel() {
    private val _state = MutableStateFlow(PokemonDetailUiState())
    val state = _state.asStateFlow()

    init {
        loadPokemon()
        observeFavoriteStatus()
    }

    private fun observeFavoriteStatus() {
        viewModelScope.launch {
            toggleFavoriteUseCase.isFavorite(name).collect { isFav ->
                _state.update { it.copy(isFavorite = isFav) }
            }
        }
    }

    fun toggleFavorite() {
        viewModelScope.launch {
            toggleFavoriteUseCase.toggle(name)
        }
    }

    fun loadPokemon() {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true, error = null) }
            try {
                _state.update { it.copy(isLoading = false, pokemon = getPokemonDetail(name)) }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Exception) {
                _state.update {
                    it.copy(isLoading = false, error = "No se pudo cargar el Pokémon. Intenta de nuevo.")
                }
            }
        }
    }
}

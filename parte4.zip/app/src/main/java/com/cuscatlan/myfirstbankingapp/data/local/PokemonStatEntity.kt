package com.cuscatlan.myfirstbankingapp.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index

@Entity(
    tableName = "pokemon_stats",
    primaryKeys = ["pokemonId", "name"],
    foreignKeys = [
        ForeignKey(
            entity = PokemonDetailEntity::class,
            parentColumns = ["pokemonId"],
            childColumns = ["pokemonId"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
    indices = [Index("pokemonId")],
)
data class PokemonStatEntity(
    val pokemonId: Int,
    val name: String,
    val baseValue: Int,
    val position: Int,
)

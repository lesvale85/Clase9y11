package com.cuscatlan.myfirstbankingapp.data.repository

import com.cuscatlan.myfirstbankingapp.domain.repository.FavoriteRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import com.cuscatlan.myfirstbankingapp.data.local.FavoriteDao //Adicion
import com.cuscatlan.myfirstbankingapp.data.local.FavoriteEntity //Adicion
import kotlinx.coroutines.flow.first

//class FavoriteRepositoryImpl : FavoriteRepository {
//    private val favoriteNames = MutableStateFlow<Set<String>>(emptySet())
//
//    override fun isFavorite(name: String): Flow<Boolean> {
//        return favoriteNames.map { set -> name.lowercase() in set }
//    }
//
//    override suspend fun toggleFavorite(name: String) {
//        favoriteNames.update { current ->
//            val key = name.lowercase()
//            if (key in current) current - key else current + key
//        }
//    }
//}
//Se modifica clase, para usar FavoriteDao en lugar del estado en memoria
class FavoriteRepositoryImpl(
    private val favoriteDao: FavoriteDao
) : FavoriteRepository {

    override fun isFavorite(name: String): Flow<Boolean> {
        return favoriteDao.isFavorite(name)
    }

    override suspend fun toggleFavorite(name: String) {
        val currentlyFavorite = favoriteDao.isFavorite(name).first()
        if (currentlyFavorite) {
            favoriteDao.deleteFavorite(name)
        } else {
            favoriteDao.insertFavorite(FavoriteEntity(pokemonName = name.lowercase()))
        }
    }
    //
    override fun getFavorites(): Flow<List<String>> {
        return favoriteDao.getAllFavorites()
    }
}

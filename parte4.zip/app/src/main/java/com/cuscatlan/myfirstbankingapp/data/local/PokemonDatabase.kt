package com.cuscatlan.myfirstbankingapp.data.local

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [PokemonEntity::class,
                PokemonDetailEntity::class,
                PokemonStatEntity::class,
                FavoriteEntity::class //Se adiciona la nueva entidad
               ],
    version = 3, //Se actualiza version a 3, ya que se agrega un nuevo Entity
    exportSchema = false,
)
abstract class PokemonDatabase : RoomDatabase() {
    abstract fun pokemonDao(): PokemonDao
    abstract fun detailDao(): PokemonDetailDao
    abstract fun favoriteDao(): FavoriteDao // Se adiciona nuevo Dao de favoritos
}

package com.cuscatlan.myfirstbankingapp.data.remote

import com.google.gson.annotations.SerializedName
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

data class PokemonPageDto(val results: List<PokemonSummaryDto>)
data class PokemonSummaryDto(val name: String, val url: String)
data class PokemonDto(
    val id: Int,
    val name: String,
    val height: Int,
    val weight: Int,
    val sprites: PokemonSpritesDto,
    val types: List<PokemonTypeSlotDto>,
    val stats: List<PokemonStatSlotDto>
)
data class PokemonSpritesDto(val other: PokemonOtherSpritesDto?)
data class PokemonOtherSpritesDto(@SerializedName("official-artwork") val officialArtwork: OfficialArtworkDto?)
data class OfficialArtworkDto(@SerializedName("front_default") val frontDefault: String?)
data class PokemonTypeSlotDto(val type: NamedResourceDto)
data class PokemonStatSlotDto(@SerializedName("base_stat") val baseStat: Int, val stat: NamedResourceDto)
data class NamedResourceDto(val name: String)

interface PokeApi {
    @GET("pokemon")
    suspend fun getPokemonPage(
        @Query("limit") limit: Int = 30,
        @Query("offset") offset: Int = 0
    ): PokemonPageDto

    @GET("pokemon/{name}")
    suspend fun getPokemon(@Path("name") name: String): PokemonDto
}

package com.cuscatlan.myfirstbankingapp.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import com.cuscatlan.myfirstbankingapp.domain.repository.SettingRepository
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.Flow
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.preferencesDataStore
import okio.IOException


val Context.settings by preferencesDataStore(name = "settings")

class SettingsRepositoryImpl
    (private val store: DataStore<Preferences>) : SettingRepository{

    override val compact = store.data
        .catch { error ->
            if (error is IOException) emit (value = emptyPreferences()) else throw error
        }
        .map {it[COMPACT] ?: false }
        .distinctUntilChanged()
    override suspend fun SetCompact(value: Boolean){
    //override suspend fun setCompact(value: Boolean){
        store.edit { it[COMPACT] = value }
    }

    private companion object{
        val COMPACT = booleanPreferencesKey(name = "compact_view")
    }
}

package com.cuscatlan.myfirstbankingapp.data.local

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

@Entity(
    tableName = "pokemon_details",
    foreignKeys = [
        ForeignKey(
            entity = PokemonEntity::class,
            parentColumns = ["id"],
            childColumns = ["pokemonId"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
)
data class PokemonDetailEntity(
    @PrimaryKey val pokemonId: Int,
    val heightDm: Int,
    val weightHg: Int,
    val imageUrl: String?,
    val typeJson: String,
    @ColumnInfo(defaultValue = "0") val lastUpdate: Long = 0L,
)

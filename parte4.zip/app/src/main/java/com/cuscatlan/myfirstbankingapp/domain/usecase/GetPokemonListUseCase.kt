package com.cuscatlan.myfirstbankingapp.domain.usecase

import com.cuscatlan.myfirstbankingapp.domain.model.Pokemon
import com.cuscatlan.myfirstbankingapp.domain.repository.PokemonRepository
import kotlinx.coroutines.flow.Flow

class GetPokemonListUseCase(private val repository: PokemonRepository) {
    suspend operator fun invoke(): List<Pokemon> = repository.getPokemonList()

    fun observePokemonList(): Flow<List<Pokemon>> = repository.observePokemonList()

    suspend fun refresh() {
        try {
            repository.refreshPokemonList()
        } catch (_: Exception) {}
    }

    suspend fun forceRefresh() = repository.forceRefreshFromApi()
}

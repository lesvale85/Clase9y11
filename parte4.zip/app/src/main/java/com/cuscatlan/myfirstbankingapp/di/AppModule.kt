package com.cuscatlan.myfirstbankingapp.di

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.room.Room
import com.cuscatlan.myfirstbankingapp.data.local.PokemonDatabase
import com.cuscatlan.myfirstbankingapp.data.preferences.SettingsRepositoryImpl
import com.cuscatlan.myfirstbankingapp.data.preferences.settings
import com.cuscatlan.myfirstbankingapp.data.remote.PokeApi
import com.cuscatlan.myfirstbankingapp.data.repository.FavoriteRepositoryImpl
import com.cuscatlan.myfirstbankingapp.data.repository.PokemonRepositoryImpl
import com.cuscatlan.myfirstbankingapp.domain.repository.FavoriteRepository
import com.cuscatlan.myfirstbankingapp.domain.repository.PokemonRepository
import com.cuscatlan.myfirstbankingapp.domain.repository.SettingRepository
import com.cuscatlan.myfirstbankingapp.domain.usecase.GetPokemonDetailUseCase
import com.cuscatlan.myfirstbankingapp.domain.usecase.GetPokemonListUseCase
import com.cuscatlan.myfirstbankingapp.domain.usecase.ToggleFavoriteUseCase
import com.cuscatlan.myfirstbankingapp.presentation.detail.PokemonDetailViewModel
import com.cuscatlan.myfirstbankingapp.presentation.home.PokemonListViewModel
import org.koin.android.ext.koin.androidContext
import org.koin.core.module.dsl.bind
import org.koin.core.module.dsl.singleOf
import org.koin.core.module.dsl.viewModel
import org.koin.core.module.dsl.viewModelOf
import org.koin.dsl.module
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

val appModule = module {

    // 1. Configuración de Red (PokeApi)
    single {
        Retrofit.Builder()
            .baseUrl("https://pokeapi.co/api/v2/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(PokeApi::class.java)
    }

    // 2. Base de Datos Room
    single {
        Room.databaseBuilder(
            androidContext(),
            PokemonDatabase::class.java,
            "pokemon_database",
        ).fallbackToDestructiveMigration(dropAllTables = true).build()
    }

    single { get<PokemonDatabase>().favoriteDao() }

    // 3. Repositorios
    singleOf(::PokemonRepositoryImpl) { bind<PokemonRepository>() }
    singleOf(::FavoriteRepositoryImpl) { bind<FavoriteRepository>() }
    single<DataStore<Preferences>> { androidContext().settings }
    singleOf(::SettingsRepositoryImpl) { bind<SettingRepository>() }

    // 4. Casos de Uso
    singleOf(::GetPokemonListUseCase)
    singleOf(::GetPokemonDetailUseCase)
    singleOf(::ToggleFavoriteUseCase)

    // 5. ViewModels
    viewModelOf(::PokemonListViewModel)
    viewModel { (name: String) ->
        PokemonDetailViewModel(
            name = name,
            getPokemonDetail = get(),
            toggleFavoriteUseCase = get(),
        )
    }
}

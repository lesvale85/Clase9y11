package com.cuscatlan.myfirstbankingapp.data.local

import androidx.room.Embedded
import androidx.room.Relation

data class CachedPokemonDetail(
    @Embedded val detail: PokemonDetailEntity,
    @Relation(parentColumn = "pokemonId", entityColumn = "id")
    val pokemon: PokemonEntity,
    @Relation(parentColumn = "pokemonId", entityColumn = "pokemonId")
    val stats: List<PokemonStatEntity>,
)

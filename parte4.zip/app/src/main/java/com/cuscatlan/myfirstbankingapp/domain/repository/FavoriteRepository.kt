package com.cuscatlan.myfirstbankingapp.domain.repository

import kotlinx.coroutines.flow.Flow

interface FavoriteRepository {
    fun isFavorite(name: String): Flow<Boolean>
    fun getFavorites(): Flow<List<String>> //Se agrega un nuevo método
    suspend fun toggleFavorite(name: String)
}

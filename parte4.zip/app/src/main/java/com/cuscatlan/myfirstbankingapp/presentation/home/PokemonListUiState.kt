package com.cuscatlan.myfirstbankingapp.presentation.home

import com.cuscatlan.myfirstbankingapp.domain.model.Pokemon

data class PokemonListUiState(
    val isLoading: Boolean = true,
    val pokemon: List<Pokemon> = emptyList(),
    val query: String = "",
    val showOnlyFavorites: Boolean = false,
    val favoriteNames: Set<String> = emptySet(),
    val isCompact: Boolean = false, // EStado de vista compacto
    val isSavingCompact: Boolean = false, //Indica si se guardó
    val settingsError: String? = null, //Mnesjae de error
    val error: String? = null,
) {
    val filteredPokemon: List<Pokemon>
        get() = pokemon.filter { item ->
            val matchesQuery = item.name.contains(query.trim(), ignoreCase = true)
            val matchesFavorite = !showOnlyFavorites || (item.name.lowercase() in favoriteNames)
            matchesQuery && matchesFavorite
        }
}

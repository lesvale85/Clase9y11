package com.cuscatlan.myfirstbankingapp.presentation.detail

import com.cuscatlan.myfirstbankingapp.domain.model.PokemonDetail

data class PokemonDetailUiState(
    val isLoading: Boolean = true,
    val pokemon: PokemonDetail? = null,
    val error: String? = null,
    val isFavorite: Boolean = false
)

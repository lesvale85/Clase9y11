package com.cuscatlan.myfirstbankingapp.data.repository

import androidx.room.withTransaction
import com.cuscatlan.myfirstbankingapp.data.local.PokemonDatabase
import com.cuscatlan.myfirstbankingapp.data.local.PokemonStatEntity
import com.cuscatlan.myfirstbankingapp.data.mapper.toDetailEntity
import com.cuscatlan.myfirstbankingapp.data.mapper.toDomain
import com.cuscatlan.myfirstbankingapp.data.mapper.toEntity
import com.cuscatlan.myfirstbankingapp.data.mapper.toSummaryEntity
import com.cuscatlan.myfirstbankingapp.data.remote.PokeApi
import com.cuscatlan.myfirstbankingapp.domain.model.Pokemon
import com.cuscatlan.myfirstbankingapp.domain.model.PokemonDetail
import com.cuscatlan.myfirstbankingapp.domain.repository.PokemonRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class PokemonRepositoryImpl(
    private val api: PokeApi,
    private val db: PokemonDatabase,
) : PokemonRepository {
    private val listRefresh = Mutex()
    private val detailRefresh = Mutex()

    override fun observePokemonList(): Flow<List<Pokemon>> = db.pokemonDao().observeAll()
        .map { rows -> rows.map { it.toDomain() } }
        .distinctUntilChanged()

    override fun observePokemonDetail(name: String): Flow<PokemonDetail?> = db.detailDao().observe(name)
        .map { it?.toDomain() }
        .distinctUntilChanged()

    override suspend fun refreshPokemonList() = listRefresh.withLock {
        val page = api.getPokemonPage(limit = 30, offset = 0)
        val entities = page.results.map { it.toEntity() }
        db.pokemonDao().upsertAll(items = entities)
    }

    override suspend fun refreshPokemonDetail(name: String) = detailRefresh.withLock {
        val dto = api.getPokemon(name)
        val summaryEntity = dto.toSummaryEntity()
        val detailEntity = dto.toDetailEntity()
        val stats = dto.stats.mapIndexed { index, item ->
            PokemonStatEntity(
                pokemonId = dto.id,
                name = item.stat.name,
                baseValue = item.baseStat,
                position = index,
            )
        }
        db.withTransaction {
            db.pokemonDao().upsertAll(items = listOf(summaryEntity))
            db.detailDao().upsert(row = detailEntity)
            db.detailDao().deleteStats(dto.id)
            db.detailDao().insertStats(rows = stats)
        }
    }

    override suspend fun forceRefreshFromApi() = listRefresh.withLock {
        val page = api.getPokemonPage(limit = 30, offset = 0)
        val entities = page.results.map { it.toEntity() }
        db.withTransaction {
            db.pokemonDao().clearPokemonCache()
            db.pokemonDao().upsertAll(items = entities)
        }
    }

    override suspend fun getPokemonList(): List<Pokemon> {
        try {
            refreshPokemonList()
        } catch (_: Exception) { }
        
        var list = db.pokemonDao().observeAll().first()
        if (list.isEmpty()) {
            val seedPokemon = listOf(
                com.cuscatlan.myfirstbankingapp.data.local.PokemonEntity(1, "bulbasaur", "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/1.png"),
                com.cuscatlan.myfirstbankingapp.data.local.PokemonEntity(4, "charmander", "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/4.png"),
                com.cuscatlan.myfirstbankingapp.data.local.PokemonEntity(7, "squirtle", "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/7.png"),
                com.cuscatlan.myfirstbankingapp.data.local.PokemonEntity(25, "pikachu", "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/25.png"),
                com.cuscatlan.myfirstbankingapp.data.local.PokemonEntity(150, "mewtwo", "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/150.png")
            )
            db.pokemonDao().upsertAll(seedPokemon)
            list = db.pokemonDao().observeAll().first()
        }
        return list.map { it.toDomain() }
    }

    override suspend fun getPokemonDetail(name: String): PokemonDetail {
        try {
            refreshPokemonDetail(name)
        } catch (_: Exception) { }
        
        db.detailDao().observe(name).first()?.toDomain()?.let { return it }

        db.pokemonDao().findByName(name)?.let { summary ->
            return PokemonDetail(
                id = summary.id,
                name = summary.name,
                heightMeters = 1.0f,
                weightKilograms = 10.0f,
                imageUrl = summary.imageUrl,
                types = listOf("normal"),
                stats = emptyList()
            )
        }

        return api.getPokemon(name).toDomain()
    }
}

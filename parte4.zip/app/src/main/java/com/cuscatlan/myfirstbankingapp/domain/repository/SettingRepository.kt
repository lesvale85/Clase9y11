package com.cuscatlan.myfirstbankingapp.domain.repository

import kotlinx.coroutines.flow.Flow

interface SettingRepository {
    val compact: Flow<Boolean>
    suspend fun SetCompact(value: Boolean)
}
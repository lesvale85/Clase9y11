package com.cuscatlan.myfirstbankingapp.data.database

sealed interface SearchValidationResult {
    object Valid : SearchValidationResult
    object EmptyOrBlank : SearchValidationResult
    object ExceedsMaxLength : SearchValidationResult
}

class SearchValidator(private val maxLength: Int = 50) {
    fun validate(query: String?): SearchValidationResult {
        if (query.isNullOrBlank()) {
            return SearchValidationResult.EmptyOrBlank
        }
        if (query.length > maxLength) {
            return SearchValidationResult.ExceedsMaxLength
        }
        return SearchValidationResult.Valid
    }
}
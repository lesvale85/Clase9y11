package com.cuscatlan.myfirstbankingapp.domain.usecase

import com.cuscatlan.myfirstbankingapp.domain.model.PokemonDetail
import com.cuscatlan.myfirstbankingapp.domain.repository.PokemonRepository

class GetPokemonDetailUseCase(private val repository: PokemonRepository) {
    suspend operator fun invoke(name: String): PokemonDetail = repository.getPokemonDetail(name)
}

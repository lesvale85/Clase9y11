package com.cuscatlan.myfirstbankingapp.domain.model

data class PokemonDetail(
    val id: Int,
    val name: String,
    val heightMeters: Float,
    val weightKilograms: Float,
    val imageUrl: String?,
    val types: List<String>,
    val stats: List<PokemonStat>
)

data class PokemonStat(
    val name: String,
    val baseValue: Int
)

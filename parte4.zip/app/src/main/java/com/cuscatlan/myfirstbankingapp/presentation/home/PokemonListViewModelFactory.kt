package com.cuscatlan.myfirstbankingapp.presentation.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.cuscatlan.myfirstbankingapp.domain.repository.FavoriteRepository
import com.cuscatlan.myfirstbankingapp.domain.repository.SettingRepository
import com.cuscatlan.myfirstbankingapp.domain.usecase.GetPokemonListUseCase

class PokemonListViewModelFactory(
    private val getPokemonList: GetPokemonListUseCase,
    private val favoriteRepository: FavoriteRepository,
    private val settingRepository: SettingRepository,
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(PokemonListViewModel::class.java)) {
            return PokemonListViewModel(getPokemonList, favoriteRepository, settingRepository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

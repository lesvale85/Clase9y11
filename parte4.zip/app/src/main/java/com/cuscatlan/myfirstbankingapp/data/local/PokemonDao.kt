package com.cuscatlan.myfirstbankingapp.data.local

import androidx.room.Dao
import androidx.room.Query
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
interface PokemonDao {
    @Query("SELECT * FROM pokemon ORDER BY id")
    fun observeAll(): Flow<List<PokemonEntity>>

    @Query("SELECT * FROM pokemon WHERE name = :name")
    suspend fun findByName(name: String): PokemonEntity?

    @Query("SELECT * FROM pokemon WHERE name LIKE '%' || :query || '%' ORDER BY id")
    fun search(query: String): Flow<List<PokemonEntity>>

    @Upsert
    suspend fun upsertAll(items: List<PokemonEntity>)

    @Query("DELETE FROM pokemon")
    suspend fun clearPokemonCache()
}

package com.cuscatlan.myfirstbankingapp.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

//Se crea una nueva entidad para Favoritos
@Entity(tableName = "favorites")
data class FavoriteEntity(
    @PrimaryKey val pokemonName: String,
    val addedAt: Long = System.currentTimeMillis()
)
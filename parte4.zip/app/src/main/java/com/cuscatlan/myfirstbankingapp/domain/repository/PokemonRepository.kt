package com.cuscatlan.myfirstbankingapp.domain.repository

import com.cuscatlan.myfirstbankingapp.domain.model.Pokemon
import com.cuscatlan.myfirstbankingapp.domain.model.PokemonDetail
import kotlinx.coroutines.flow.Flow

interface PokemonRepository {
    suspend fun getPokemonList(): List<Pokemon>
    suspend fun getPokemonDetail(name: String): PokemonDetail

    fun observePokemonList(): Flow<List<Pokemon>>
    fun observePokemonDetail(name: String): Flow<PokemonDetail?>
    suspend fun refreshPokemonList()
    suspend fun refreshPokemonDetail(name: String)
    suspend fun forceRefreshFromApi()
}

package com.cuscatlan.myfirstbankingapp.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

//Se crea archivo Dao para Favoritos, para las consultas SQL requeridas
@Dao
interface FavoriteDao {
    @Query("SELECT EXISTS(SELECT 1 FROM favorites WHERE LOWER(pokemonName) = LOWER(:name))")
    fun isFavorite(name: String): Flow<Boolean>

    @Query("SELECT pokemonName FROM favorites")
    fun getAllFavorites(): Flow<List<String>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFavorite(favorite: FavoriteEntity)

    @Query("DELETE FROM favorites WHERE LOWER(pokemonName) = LOWER(:name)")
    suspend fun deleteFavorite(name: String)
}

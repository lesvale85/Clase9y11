package com.cuscatlan.myfirstbankingapp.domain.usecase

import com.cuscatlan.myfirstbankingapp.domain.repository.FavoriteRepository
import kotlinx.coroutines.flow.Flow

class ToggleFavoriteUseCase(
    private val favoriteRepository: FavoriteRepository,
) {
    fun isFavorite(name: String): Flow<Boolean> = favoriteRepository.isFavorite(name)

    suspend fun toggle(name: String) = favoriteRepository.toggleFavorite(name)
}

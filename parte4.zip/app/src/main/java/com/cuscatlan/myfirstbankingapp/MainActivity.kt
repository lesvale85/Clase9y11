package com.cuscatlan.myfirstbankingapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.cuscatlan.myfirstbankingapp.presentation.detail.PokemonDetailScreen
import com.cuscatlan.myfirstbankingapp.presentation.detail.PokemonDetailViewModel
import com.cuscatlan.myfirstbankingapp.presentation.home.HomeScreen
import com.cuscatlan.myfirstbankingapp.presentation.home.PokemonListViewModel
import com.cuscatlan.myfirstbankingapp.ui.theme.MyFirstBankingAppTheme
import org.koin.androidx.compose.koinViewModel
import org.koin.core.parameter.parametersOf

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val navController = rememberNavController()
            MyFirstBankingAppTheme(dynamicColor = false) {
                Surface(Modifier.fillMaxSize()) {
                    NavHost(navController = navController, startDestination = "home") {
                        composable("home") {
                            val pokemonViewModel: PokemonListViewModel = koinViewModel()
                            HomeScreen(pokemonViewModel) { pokemon ->
                                navController.navigate("pokemon/${pokemon.name}")
                            }
                        }
                        composable(
                            route = "pokemon/{name}",
                            arguments = listOf(navArgument("name") { type = NavType.StringType })
                        ) { entry ->
                            val name = entry.arguments?.getString("name").orEmpty()
                            val pokemonViewModel: PokemonDetailViewModel = koinViewModel(
                                parameters = { parametersOf(name) }
                            )
                            PokemonDetailScreen(pokemonViewModel) { navController.popBackStack() }
                        }
                    }
                }
            }
        }
    }
}

package com.cuscatlan.myfirstbankingapp

import com.cuscatlan.myfirstbankingapp.data.database.SearchValidationResult
import com.cuscatlan.myfirstbankingapp.data.database.SearchValidator
import org.junit.Assert.assertEquals
import org.junit.Test

class SearchValidatorTest {

    private val validator = SearchValidator(maxLength = 50)

    @Test
    fun `Cuando la consulta es nula o vacia, retorna EmptyOrBlank`() {
        assertEquals(SearchValidationResult.EmptyOrBlank, validator.validate(null))
        assertEquals(SearchValidationResult.EmptyOrBlank, validator.validate(""))
    }

    @Test
    fun `Cuando la consulta contiene solo espacios en blanco, retorna EmptyOrBlank`() {
        assertEquals(SearchValidationResult.EmptyOrBlank, validator.validate("   "))
        assertEquals(SearchValidationResult.EmptyOrBlank, validator.validate("\t\n"))
    }

    @Test
    fun `Cuando la consulta es valida (caso normal y borde minimo de 1 caracter), retorna Valid`() {
        assertEquals(SearchValidationResult.Valid, validator.validate("Pikachu"))
        // Caso de borde inferior (1 carácter)
        assertEquals(SearchValidationResult.Valid, validator.validate("a"))
    }

    @Test
    fun `cuando la consulta alcanza exactamente el limite maximo de 50 caracteres, retorna Valid`() {
        val exact50 = "a".repeat(50)
        assertEquals(SearchValidationResult.Valid, validator.validate(exact50))
    }

    @Test
    fun `cuando la consulta supera el limite maximo con 51 caracteres, retorna ExceedsMaxLength`() {
        val over51 = "a".repeat(51)
        assertEquals(SearchValidationResult.ExceedsMaxLength, validator.validate(over51))
    }
}
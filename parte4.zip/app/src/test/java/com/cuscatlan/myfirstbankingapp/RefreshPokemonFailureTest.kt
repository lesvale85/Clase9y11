package com.cuscatlan.myfirstbankingapp

import com.cuscatlan.myfirstbankingapp.domain.model.Pokemon
import com.cuscatlan.myfirstbankingapp.domain.model.PokemonDetail
import com.cuscatlan.myfirstbankingapp.domain.repository.PokemonRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertThrows
import org.junit.Test
import java.io.IOException

class RefreshPokemonFailureTest {

    class FakeOfflinePokemonRepository : PokemonRepository {
        override suspend fun getPokemonList(): List<Pokemon> = emptyList()
        override suspend fun getPokemonDetail(name: String): PokemonDetail = throw NotImplementedError()
        override fun observePokemonList(): Flow<List<Pokemon>> = flowOf(emptyList())
        override fun observePokemonDetail(name: String): Flow<PokemonDetail?> = flowOf(null)
        
        override suspend fun refreshPokemonList() {
            throw IOException("Se espera IOException por falta de red")
        }

        override suspend fun refreshPokemonDetail(name: String) {}
        override suspend fun forceRefreshFromApi() {
            throw IOException("Se espera IOException por falta de red")
        }
    }

    @Test
    fun `cuando no hay red, repository refresh lanza IOException`() {
        val fakeRepo = FakeOfflinePokemonRepository()

        assertThrows(IOException::class.java) {
            runBlocking {
                fakeRepo.refreshPokemonList()
            }
        }
    }
}

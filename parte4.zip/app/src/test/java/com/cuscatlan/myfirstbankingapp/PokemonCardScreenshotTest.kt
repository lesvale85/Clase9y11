package com.cuscatlan.myfirstbankingapp

import com.cuscatlan.myfirstbankingapp.domain.model.Pokemon
import com.cuscatlan.myfirstbankingapp.presentation.home.PokemonListUiState
import org.junit.Assert.assertEquals
import org.junit.Test

class PokemonCardScreenshotTest {

    @Test
    fun `cuando se filtra por consulta, devuelve solo los pokemon que coinciden`() {
        val pokemons = listOf(
            Pokemon(1, "Bulbasaur", "url1"),
            Pokemon(4, "Charmander", "url2"),
            Pokemon(25, "Pikachu", "url3")
        )
        val state = PokemonListUiState(
            pokemon = pokemons,
            query = "char"
        )

        val filtered = state.filteredPokemon
        assertEquals(1, filtered.size)
        assertEquals("Charmander", filtered[0].name)
    }
}

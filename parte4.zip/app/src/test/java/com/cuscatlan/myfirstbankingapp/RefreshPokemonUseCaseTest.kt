package com.cuscatlan.myfirstbankingapp

import com.cuscatlan.myfirstbankingapp.domain.model.Pokemon
import com.cuscatlan.myfirstbankingapp.domain.model.PokemonDetail
import com.cuscatlan.myfirstbankingapp.domain.repository.PokemonRepository
import com.cuscatlan.myfirstbankingapp.domain.usecase.GetPokemonListUseCase
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertTrue
import org.junit.Test

class RefreshPokemonUseCaseTest {

    class FakePokemonRepository : PokemonRepository {
        var refreshCalled = false

        override suspend fun getPokemonList(): List<Pokemon> = emptyList()
        override suspend fun getPokemonDetail(name: String): PokemonDetail = throw NotImplementedError()
        override fun observePokemonList(): Flow<List<Pokemon>> = flowOf(emptyList())
        override fun observePokemonDetail(name: String): Flow<PokemonDetail?> = flowOf(null)
        
        override suspend fun refreshPokemonList() {
            refreshCalled = true
        }

        override suspend fun refreshPokemonDetail(name: String) {}
        override suspend fun forceRefreshFromApi() {
            refreshCalled = true
        }
    }

    @Test
    fun `Cuando se ejecuta refresh con exito, se llama a refresh en el Repositorio`() = runBlocking {
        val fakeRepo = FakePokemonRepository()
        val useCase = GetPokemonListUseCase(fakeRepo)

        useCase.refresh()

        assertTrue("El metodo refresh del repositorio debió ser llamado", fakeRepo.refreshCalled)
    }
}

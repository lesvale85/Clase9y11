package com.cuscatlan.myfirstbankingapp

import com.cuscatlan.myfirstbankingapp.data.local.CachedPokemonDetail
import com.cuscatlan.myfirstbankingapp.data.local.PokemonDetailEntity
import com.cuscatlan.myfirstbankingapp.data.local.PokemonEntity
import com.cuscatlan.myfirstbankingapp.data.local.PokemonStatEntity
import com.cuscatlan.myfirstbankingapp.data.mapper.toDomain
import com.cuscatlan.myfirstbankingapp.data.mapper.toEntity
import com.cuscatlan.myfirstbankingapp.data.remote.*
import org.junit.Assert.assertEquals
import org.junit.Test

class PokemonMappersTest {

    @Test
    fun `Cuando se mapea PokemonSummaryDto a Domain y Entity, extrae id y construye url correctamente`() {
        val summaryDto = PokemonSummaryDto(
            name = "pikachu",
            url = "https://pokeapi.co/api/v2/pokemon/25/"
        )

        val domain = summaryDto.toDomain()
        assertEquals(25, domain.id)
        assertEquals("pikachu", domain.name)
        assertEquals("https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/25.png", domain.imageUrl)

        val entity = summaryDto.toEntity()
        assertEquals(25, entity.id)
        assertEquals("pikachu", entity.name)
        assertEquals("https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/25.png", entity.imageUrl)
    }

    @Test
    fun `Cuando se mapea PokemonDto a PokemonDetail Domain, convierte unidades y mapea tipos y estadisticas`() {
        val dto = PokemonDto(
            id = 1,
            name = "bulbasaur",
            height = 7, // 7 decimetros -> 0.7 metros
            weight = 69, // 69 hectogramos -> 6.9 kilogramos
            sprites = PokemonSpritesDto(
                other = PokemonOtherSpritesDto(
                    officialArtwork = OfficialArtworkDto(frontDefault = "custom_image.png")
                )
            ),
            types = listOf(PokemonTypeSlotDto(NamedResourceDto("grass"))),
            stats = listOf(PokemonStatSlotDto(baseStat = 45, stat = NamedResourceDto("hp")))
        )

        val detail = dto.toDomain()
        assertEquals(1, detail.id)
        assertEquals("bulbasaur", detail.name)
        assertEquals(0.7f, detail.heightMeters)
        assertEquals(6.9f, detail.weightKilograms)
        assertEquals("custom_image.png", detail.imageUrl)
        assertEquals(listOf("grass"), detail.types)
        assertEquals(1, detail.stats.size)
        assertEquals("hp", detail.stats[0].name)
        assertEquals(45, detail.stats[0].baseValue)
    }

    @Test
    fun `Cuando se mapea PokemonEntity a Domain, retorna el modelo correcto`() {
        val entity = PokemonEntity(
            id = 4,
            name = "charmander",
            imageUrl = "charmander.png"
        )

        val domain = entity.toDomain()
        assertEquals(4, domain.id)
        assertEquals("charmander", domain.name)
        assertEquals("charmander.png", domain.imageUrl)
    }

    @Test
    fun `Cuando se mapea CachedPokemonDetail a Domain, deserializa correctamente el json de tipos`() {
        val pokemonEntity = PokemonEntity(1, "bulbasaur", "img.png")
        val detailEntity = PokemonDetailEntity(
            pokemonId = 1,
            heightDm = 7,
            weightHg = 69,
            imageUrl = "img.png",
            typeJson = "[\"grass\",\"poison\"]",
            lastUpdate = 123456789L
        )
        val stats = listOf(PokemonStatEntity(1, "hp", 45, 0))

        val cached = CachedPokemonDetail(
            pokemon = pokemonEntity,
            detail = detailEntity,
            stats = stats
        )

        val domain = cached.toDomain()
        assertEquals(1, domain.id)
        assertEquals("bulbasaur", domain.name)
        assertEquals(0.7f, domain.heightMeters)
        assertEquals(6.9f, domain.weightKilograms)
        assertEquals(listOf("grass", "poison"), domain.types)
        assertEquals(1, domain.stats.size)
        assertEquals("hp", domain.stats[0].name)
        assertEquals(45, domain.stats[0].baseValue)
    }
}
